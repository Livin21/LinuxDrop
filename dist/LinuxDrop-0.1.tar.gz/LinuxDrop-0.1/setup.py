from distutils.core import setup

setup(
    name='LinuxDrop',
    version='0.1',
    packages=['sender', 'receiver'],
    url='https://github.com/Livin21/LinuxDrop',
    license='MIT',
    author='livin',
    author_email='livinmathew99@gmail.com',
    description='Airdrop alternative for Linux <3'
)
